# Signal Scout v0.1.1

Fixes:
- HTTPS router access should now work.
- Adds Test Read Once button.
- Shows raw HTTP/XML reply for debugging.
- Better status messages.

Upload `signal_scout_android_v0_1_1_full_project.zip` to the repo, then use the included workflow or the release workflow in chat.
