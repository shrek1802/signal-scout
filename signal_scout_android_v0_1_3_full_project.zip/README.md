# Signal Scout v0.1.3

Fix:
- Huawei password_type 4 login attempt added.
- Falls back to older login method if first method fails.
- Shows debug output for both login attempts.
