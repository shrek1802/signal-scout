# Signal Scout v0.1

Android signal alignment tool for Huawei B535.

## v0.1 features
- Reads `/api/device/signal` every second
- Big SINR display
- RSRP / RSRQ / RSSI / Band
- PCI / EARFCN / Cell ID / eNodeB
- Beep and vibrate on new best
- Read-only. Band locking comes in v0.2.

## Build APK
Go to **Actions → Build Signal Scout APK → Run workflow**.

The APK will appear in **Artifacts** as `Signal-Scout-v0.1-debug-apk`.
