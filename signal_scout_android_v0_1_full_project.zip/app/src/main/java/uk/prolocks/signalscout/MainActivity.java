package uk.prolocks.signalscout;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.os.VibrationEffect;
import android.content.Context;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.*;
import android.view.View;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private EditText routerUrl;
    private TextView status, sinrView, bestView, rsrpView, rsrqView, rssiView, bandView, cellView, rawView;
    private Button startBtn, stopBtn, resetBtn;
    private Switch beepSwitch;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean running = false;
    private double bestSinr = -999;
    private ToneGenerator tone;
    private Vibrator vibrator;

    private final Runnable poller = new Runnable() {
        @Override public void run() {
            if (!running) return;
            readSignal();
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 80);
        vibrator = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);
        root.setBackgroundColor(Color.rgb(16,16,16));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Signal Scout v0.1");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0,0,0,16);
        root.addView(title);

        routerUrl = new EditText(this);
        routerUrl.setText("https://hirouter.net");
        routerUrl.setHint("https://hirouter.net or http://192.168.8.1");
        routerUrl.setTextColor(Color.WHITE);
        routerUrl.setHintTextColor(Color.GRAY);
        routerUrl.setSingleLine(true);
        root.addView(routerUrl);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(buttons);

        startBtn = makeButton("Start Live");
        stopBtn = makeButton("Stop");
        resetBtn = makeButton("Reset Best");
        buttons.addView(startBtn, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(stopBtn, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(resetBtn, new LinearLayout.LayoutParams(0, -2, 1));

        beepSwitch = new Switch(this);
        beepSwitch.setText("Beep faster when SINR gets better");
        beepSwitch.setTextColor(Color.WHITE);
        beepSwitch.setChecked(true);
        root.addView(beepSwitch);

        status = txt("Stopped", 14, Color.LTGRAY);
        root.addView(status);

        sinrView = big("-- dB", 82);
        root.addView(label("SINR / SNR - aim highest"));
        root.addView(sinrView);

        bestView = txt("Best: --", 24, Color.WHITE);
        bestView.setGravity(Gravity.CENTER);
        root.addView(bestView);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        rsrpView = metric("RSRP\n--");
        rsrqView = metric("RSRQ\n--");
        row1.addView(rsrpView, new LinearLayout.LayoutParams(0, -2, 1));
        row1.addView(rsrqView, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        rssiView = metric("RSSI\n--");
        bandView = metric("Band\n--");
        row2.addView(rssiView, new LinearLayout.LayoutParams(0, -2, 1));
        row2.addView(bandView, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row2);

        cellView = txt("PCI: --\nEARFCN: --\nCell ID: --\neNodeB: --", 16, Color.LTGRAY);
        cellView.setPadding(12,12,12,12);
        root.addView(cellView);

        rawView = txt("", 11, Color.GRAY);
        root.addView(rawView);

        startBtn.setOnClickListener(v -> start());
        stopBtn.setOnClickListener(v -> stop());
        resetBtn.setOnClickListener(v -> {
            bestSinr = -999;
            bestView.setText("Best: --");
        });

        setContentView(scroll);
    }

    private Button makeButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }

    private TextView label(String s) {
        TextView v = txt(s, 18, Color.LTGRAY);
        v.setGravity(Gravity.CENTER);
        v.setPadding(0,18,0,0);
        return v;
    }

    private TextView big(String s, int size) {
        TextView v = txt(s, size, Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setPadding(0,8,0,8);
        v.setTypeface(null, 1);
        return v;
    }

    private TextView metric(String s) {
        TextView v = txt(s, 22, Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setPadding(8,18,8,18);
        return v;
    }

    private TextView txt(String s, int size, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        return v;
    }

    private void start() {
        running = true;
        bestSinr = -999;
        status.setText("Running...");
        handler.removeCallbacks(poller);
        handler.post(poller);
    }

    private void stop() {
        running = false;
        handler.removeCallbacks(poller);
        status.setText("Stopped");
    }

    private void readSignal() {
        new Thread(() -> {
            try {
                String base = routerUrl.getText().toString().trim();
                if (base.endsWith("/")) base = base.substring(0, base.length()-1);
                URL url = new URL(base + "/api/device/signal");
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setConnectTimeout(4000);
                con.setReadTimeout(6000);
                con.setRequestMethod("GET");
                con.setRequestProperty("Accept", "application/xml,text/xml,*/*");

                BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append("\n");
                br.close();
                String xml = sb.toString();

                runOnUiThread(() -> updateFromXml(xml));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Read failed: " + e.getMessage()));
            }
        }).start();
    }

    private void updateFromXml(String xml) {
        String sinr = pick(xml, "sinr", "snr");
        String rsrp = pick(xml, "rsrp");
        String rsrq = pick(xml, "rsrq");
        String rssi = pick(xml, "rssi");
        String band = pick(xml, "band");
        String pci = pick(xml, "pci");
        String earfcn = pick(xml, "earfcn");
        String cell = pick(xml, "cell_id");
        String enodeb = pick(xml, "enodeb_id");

        double sinrNum = num(sinr);
        sinrView.setText(sinr.length() > 0 ? sinr : "-- dB");
        sinrView.setTextColor(sinrColor(sinrNum));

        rsrpView.setText("RSRP\n" + empty(rsrp));
        rsrpView.setTextColor(rsrpColor(num(rsrp)));

        rsrqView.setText("RSRQ\n" + empty(rsrq));
        rsrqView.setTextColor(rsrqColor(num(rsrq)));

        rssiView.setText("RSSI\n" + empty(rssi));
        bandView.setText("Band\n" + (band.length() > 0 ? "B" + band : "--"));

        cellView.setText("PCI: " + empty(pci) + "\nEARFCN: " + empty(earfcn) + "\nCell ID: " + empty(cell) + "\neNodeB: " + empty(enodeb));
        rawView.setText(xml);
        status.setText("Updated");

        if (sinrNum > -900) {
            if (sinrNum > bestSinr) {
                bestSinr = sinrNum;
                bestView.setText("Best: " + bestSinr + " dB");
                vibrate();
            }
            beepForSinr(sinrNum);
        }
    }

    private void beepForSinr(double sinr) {
        if (!beepSwitch.isChecked()) return;
        int duration = 50;
        if (sinr >= 20) duration = 120;
        else if (sinr >= 13) duration = 80;
        else if (sinr >= 5) duration = 55;
        tone.startTone(ToneGenerator.TONE_PROP_BEEP, duration);
    }

    private void vibrate() {
        try {
            if (vibrator == null) return;
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(80);
            }
        } catch(Exception ignored) {}
    }

    private String pick(String xml, String... tags) {
        for (String tag: tags) {
            Matcher m = Pattern.compile("<" + tag + ">(.*?)</" + tag + ">", Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(xml);
            if (m.find()) return m.group(1).trim();
        }
        return "";
    }

    private double num(String s) {
        Matcher m = Pattern.compile("-?\\d+(\\.\\d+)?").matcher(s == null ? "" : s);
        if (m.find()) {
            try { return Double.parseDouble(m.group()); } catch(Exception ignored) {}
        }
        return -999;
    }

    private String empty(String s) {
        return s == null || s.length() == 0 ? "--" : s;
    }

    private int sinrColor(double v) {
        if (v >= 20) return Color.rgb(60,255,120);
        if (v >= 13) return Color.rgb(200,255,90);
        if (v >= 5) return Color.rgb(255,185,70);
        return Color.rgb(255,90,90);
    }

    private int rsrpColor(double v) {
        if (v >= -85) return Color.rgb(60,255,120);
        if (v >= -95) return Color.rgb(200,255,90);
        if (v >= -105) return Color.rgb(255,185,70);
        return Color.rgb(255,90,90);
    }

    private int rsrqColor(double v) {
        if (v >= -10) return Color.rgb(60,255,120);
        if (v >= -13) return Color.rgb(200,255,90);
        if (v >= -15) return Color.rgb(255,185,70);
        return Color.rgb(255,90,90);
    }
}
