# Signal Scout v0.1.4

Login fix attempt using base64(hex(sha256())) Huawei type-4 method, X-Requested-With header, and previous fallbacks.
