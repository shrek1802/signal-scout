# Signal Scout v0.1.2

Adds router login.

Use:
1. Enter router URL.
2. Enter router admin password.
3. Press LOGIN TO ROUTER.
4. If it says Logged in OK, press START or TEST READ.
