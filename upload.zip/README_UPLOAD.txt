Signal Scout GitHub Workflow Fix

Use:
1. Rename this ZIP to upload.zip
2. Upload to repo root
3. Run Apply upload.zip Update
4. Go to Actions
5. Run Build APK Release manually
6. Version: 3.9.2
7. Channel: beta

What this fixes:
- Deletes old APKs before building
- Disables Gradle cache
- Runs clean build
- Builds only :app:assembleDebug
- Copies only the new APK from app/build/outputs/apk/debug
- Deletes old release/tag before creating fresh one
- Stops old APKs being attached to new releases

After install:
- About should show v3.9.2
- Band Optimiser should show Auto Scan buttons
