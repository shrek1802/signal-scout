Signal Scout v3.5.0 real dashboard build

Use:
1. Rename this ZIP to upload.zip
2. Upload to repo root
3. Run Apply upload.zip Update
4. Run Release Manager
5. Version: 3.5.0
6. Channel: beta

Changes:
- Home screen stays unchanged
- Dashboard no longer uses fake full-screen UI overlays
- Dashboard uses background artwork only
- Real panels/cards are built on top
- Live values sit in real cards
- Side drawer is a real menu
- Router engine from v3.4.0 kept
