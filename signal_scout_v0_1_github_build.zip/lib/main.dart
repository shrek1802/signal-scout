import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const SignalScoutApp());
}

class SignalScoutApp extends StatelessWidget {
  const SignalScoutApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Signal Scout',
      theme: ThemeData.dark(useMaterial3: true),
      home: const SignalHome(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class SignalReading {
  final String raw;
  final String sinr;
  final String rsrp;
  final String rsrq;
  final String rssi;
  final String band;
  final String pci;
  final String cellId;
  final String earfcn;
  final String enodeb;

  SignalReading({
    required this.raw,
    required this.sinr,
    required this.rsrp,
    required this.rsrq,
    required this.rssi,
    required this.band,
    required this.pci,
    required this.cellId,
    required this.earfcn,
    required this.enodeb,
  });

  double? get sinrValue => _num(sinr);
  double? get rsrpValue => _num(rsrp);
  double? get rsrqValue => _num(rsrq);

  static double? _num(String value) {
    final match = RegExp(r'-?\d+(\.\d+)?').firstMatch(value);
    if (match == null) return null;
    return double.tryParse(match.group(0)!);
  }

  static String pick(String xml, List<String> tags) {
    for (final tag in tags) {
      final reg = RegExp('<$tag>(.*?)</$tag>', caseSensitive: false, dotAll: true);
      final m = reg.firstMatch(xml);
      if (m != null) return m.group(1)?.trim() ?? '';
    }
    return '';
  }

  factory SignalReading.fromXml(String xml) {
    return SignalReading(
      raw: xml,
      sinr: pick(xml, ['sinr', 'snr']),
      rsrp: pick(xml, ['rsrp']),
      rsrq: pick(xml, ['rsrq']),
      rssi: pick(xml, ['rssi']),
      band: pick(xml, ['band']),
      pci: pick(xml, ['pci']),
      cellId: pick(xml, ['cell_id', 'cellid']),
      earfcn: pick(xml, ['earfcn']),
      enodeb: pick(xml, ['enodeb_id']),
    );
  }
}

class SignalHome extends StatefulWidget {
  const SignalHome({super.key});

  @override
  State<SignalHome> createState() => _SignalHomeState();
}

class _SignalHomeState extends State<SignalHome> {
  final TextEditingController _router = TextEditingController(text: 'https://hirouter.net');
  Timer? _pollTimer;
  Timer? _beepTimer;
  SignalReading? _reading;
  String _status = 'Stopped';
  double? _bestSinr;
  bool _running = false;
  bool _beeper = true;
  bool _showRaw = false;

  @override
  void dispose() {
    _pollTimer?.cancel();
    _beepTimer?.cancel();
    _router.dispose();
    super.dispose();
  }

  Future<String> _get(String path) async {
    final base = _router.text.trim().replaceAll(RegExp(r'/$'), '');
    final uri = Uri.parse('$base$path');
    final client = HttpClient();
    client.badCertificateCallback = (cert, host, port) => true;
    client.connectionTimeout = const Duration(seconds: 4);
    try {
      final req = await client.getUrl(uri);
      req.headers.set(HttpHeaders.acceptHeader, 'application/xml,text/xml,*/*');
      final res = await req.close().timeout(const Duration(seconds: 8));
      return await res.transform(utf8.decoder).join();
    } finally {
      client.close(force: true);
    }
  }

  Future<void> _readOnce() async {
    try {
      final xml = await _get('/api/device/signal');
      final reading = SignalReading.fromXml(xml);
      final sinr = reading.sinrValue;

      if (sinr != null && (_bestSinr == null || sinr > _bestSinr!)) {
        _bestSinr = sinr;
        HapticFeedback.heavyImpact();
      }

      setState(() {
        _reading = reading;
        _status = 'Updated ${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')}:${DateTime.now().second.toString().padLeft(2, '0')}';
      });

      _updateBeeper();
    } catch (e) {
      setState(() => _status = 'Read failed: $e');
    }
  }

  void _start() {
    _pollTimer?.cancel();
    _bestSinr = null;
    setState(() {
      _running = true;
      _status = 'Running';
    });
    _readOnce();
    _pollTimer = Timer.periodic(const Duration(seconds: 1), (_) => _readOnce());
  }

  void _stop() {
    _pollTimer?.cancel();
    _beepTimer?.cancel();
    setState(() {
      _running = false;
      _status = 'Stopped';
    });
  }

  void _updateBeeper() {
    _beepTimer?.cancel();
    if (!_running || !_beeper) return;

    final sinr = _reading?.sinrValue;
    if (sinr == null) return;

    final clamped = sinr.clamp(-5, 30);
    final intervalMs = (1200 - ((clamped + 5) / 35 * 1080)).round().clamp(120, 1200);

    _beepTimer = Timer.periodic(Duration(milliseconds: intervalMs), (_) {
      SystemSound.play(SystemSoundType.click);
    });
  }

  Color _sinrColor(double? v) {
    if (v == null) return Colors.grey;
    if (v >= 20) return Colors.greenAccent;
    if (v >= 13) return Colors.limeAccent;
    if (v >= 5) return Colors.orangeAccent;
    return Colors.redAccent;
  }

  Color _rsrpColor(double? v) {
    if (v == null) return Colors.grey;
    if (v >= -85) return Colors.greenAccent;
    if (v >= -95) return Colors.limeAccent;
    if (v >= -105) return Colors.orangeAccent;
    return Colors.redAccent;
  }

  Color _rsrqColor(double? v) {
    if (v == null) return Colors.grey;
    if (v >= -10) return Colors.greenAccent;
    if (v >= -13) return Colors.limeAccent;
    if (v >= -15) return Colors.orangeAccent;
    return Colors.redAccent;
  }

  @override
  Widget build(BuildContext context) {
    final r = _reading;
    final sinr = r?.sinrValue;
    final best = _bestSinr == null ? '--' : '${_bestSinr!.toStringAsFixed(1)} dB';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Signal Scout v0.1'),
        actions: [
          IconButton(
            tooltip: 'Reset best',
            onPressed: () => setState(() => _bestSinr = null),
            icon: const Icon(Icons.restart_alt),
          )
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            TextField(
              controller: _router,
              decoration: const InputDecoration(
                labelText: 'Router URL',
                hintText: 'https://hirouter.net or http://192.168.8.1',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _running ? null : _start,
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('Start live'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton.tonalIcon(
                    onPressed: _running ? _stop : null,
                    icon: const Icon(Icons.stop),
                    label: const Text('Stop'),
                  ),
                ),
              ],
            ),
            SwitchListTile(
              value: _beeper,
              onChanged: (v) {
                setState(() => _beeper = v);
                _updateBeeper();
              },
              title: const Text('Beep faster as SINR improves'),
              subtitle: const Text('For antenna alignment'),
            ),
            Text(_status, style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 12),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  children: [
                    const Text('SINR', style: TextStyle(fontSize: 22, letterSpacing: 2)),
                    Text(
                      r?.sinr.isNotEmpty == true ? r!.sinr : '-- dB',
                      style: TextStyle(
                        fontSize: 74,
                        fontWeight: FontWeight.w900,
                        color: _sinrColor(sinr),
                      ),
                    ),
                    LinearProgressIndicator(
                      value: sinr == null ? 0 : ((sinr + 5) / 35).clamp(0, 1).toDouble(),
                      minHeight: 12,
                    ),
                    const SizedBox(height: 8),
                    Text('Best: $best', style: const TextStyle(fontSize: 22)),
                  ],
                ),
              ),
            ),

            Row(
              children: [
                Expanded(child: _metric('RSRP', r?.rsrp, _rsrpColor(r?.rsrpValue))),
                const SizedBox(width: 8),
                Expanded(child: _metric('RSRQ', r?.rsrq, _rsrqColor(r?.rsrqValue))),
              ],
            ),
            Row(
              children: [
                Expanded(child: _metric('RSSI', r?.rssi, Colors.white70)),
                const SizedBox(width: 8),
                Expanded(child: _metric('Band', r?.band.isNotEmpty == true ? 'B${r!.band}' : '--', Colors.white70)),
              ],
            ),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: DefaultTextStyle(
                  style: const TextStyle(fontSize: 16, color: Colors.white70),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('PCI: ${r?.pci.isNotEmpty == true ? r!.pci : '--'}'),
                      Text('EARFCN: ${r?.earfcn.isNotEmpty == true ? r!.earfcn : '--'}'),
                      Text('Cell ID: ${r?.cellId.isNotEmpty == true ? r!.cellId : '--'}'),
                      Text('eNodeB: ${r?.enodeb.isNotEmpty == true ? r!.enodeb : '--'}'),
                    ],
                  ),
                ),
              ),
            ),

            SwitchListTile(
              value: _showRaw,
              onChanged: (v) => setState(() => _showRaw = v),
              title: const Text('Show raw XML'),
            ),
            if (_showRaw)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: SelectableText(r?.raw ?? 'No data yet'),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _metric(String label, String? value, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Text(label, style: const TextStyle(color: Colors.white60)),
            const SizedBox(height: 4),
            Text(
              value?.isNotEmpty == true ? value! : '--',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: color),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
