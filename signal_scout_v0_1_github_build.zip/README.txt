Signal Scout v0.1

What this does:
- Reads Huawei B535 signal data every second from /api/device/signal
- Shows SINR, RSRP, RSRQ, RSSI, band, PCI, EARFCN, Cell ID and eNodeB
- Antenna alignment mode with big SINR number
- Beep gets faster as SINR gets better
- Haptic tap when a new best SINR is found
- No internet services, no adverts, only talks to your router

Default router URL:
https://hirouter.net

If that does not work, try:
http://192.168.8.1

Build:
1. Install Flutter
2. Open this folder in Android Studio or VS Code
3. Run: flutter pub get
4. Run: flutter build apk --debug
5. Install: build/app/outputs/flutter-apk/app-debug.apk

Important:
Log in to the router in a browser first if the API needs a session.
v0.1 is read-only. Band locking will be v0.2.
